import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class aula01 {

    @Test
    public void teste() {
        System.setProperty("webdriver.chrome.driver", "src/drivers/chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.manage().window().setSize(new Dimension(300, 1000));
        driver.get("https://google.com.br");
        Assertions.assertEquals("Google", driver.getTitle());
        driver.quit();
    }

    @Test
    public void automacao(){
        System.setProperty("webdriver.chrome.driver", "src/drivers/chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.get("https://automacaocombatista.herokuapp.com/treinamento/home");
        driver.findElement(By.cssSelector("li[class='bold']:nth-child(1)")).click();
        driver.findElement(By.cssSelector("a[href='/users/new']")).click();
        driver.findElement(By.id("user_name")).sendKeys("Ludgero");
        driver.findElement(By.id("user_lastname")).sendKeys("Bezerra");
        driver.findElement(By.id("user_email")).sendKeys("lud@123");
        driver.findElement(By.id("user_address")).sendKeys("Minha Casa");
        driver.findElement(By.id("user_university")).sendKeys("Catolica");
        driver.findElement(By.id("user_profile")).sendKeys("Estudante");
        driver.findElement(By.id("user_gender")).sendKeys("Masculino");
        driver.findElement(By.id("user_age")).sendKeys("28");
        driver.findElement(By.cssSelector("[type='submit']")).click();
        driver.quit();


    }
}
